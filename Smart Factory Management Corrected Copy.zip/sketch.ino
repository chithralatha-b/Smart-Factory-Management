#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <math.h> // Required for log() and pow() functions

#define TEMP_PIN A0
#define GAS_PIN A1
#define PIR_PIN 3
#define BUZZER_PIN 6
#define LED_PIN 7
#define SERIES_RESISTOR 10000 // The value of the fixed resistor in the voltage divider (10k Ohms)
#define NOMINAL_TEMP 25      // Temperature for nominal resistance (usually 25°C)
#define NOMINAL_RESISTANCE 10000 // Resistance at NOMINAL_TEMP (10k Ohms)
#define B_COEFFICIENT 3950   // Beta coefficient of the thermistor (check datasheet for exact value, 3950 is common)

LiquidCrystal_I2C lcd(0x27, 16, 2);  // LCD address 0x27, 16 columns, 2 rows

void setup() {
  pinMode(PIR_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  // The NTC circuit in the Wokwi diagram connects the NTC to GND and the 
  // series resistor to 5V. Pin A0 is connected between them.

  Serial.begin(9600); // Start serial for dashboard integration

  lcd.begin(16, 2);
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Smart Factory");
  delay(500);
  lcd.clear();
}

void loop() {
  // Read temperature from NTC sensor
  int tempValueRaw = analogRead(TEMP_PIN);
  
  // Calculate resistance of the NTC thermistor
  // The formula for resistance when the thermistor is connected to GND is R_NTC = R_series / ((1023 / ADC_value) - 1)
  float resistance;
  resistance = SERIES_RESISTOR / (1023.0 / tempValueRaw - 1.0);

  // Calculate temperature using the Beta parameter equation
  float temperature;
  temperature = resistance / NOMINAL_RESISTANCE; // (R/Ro)
  temperature = log(temperature); // ln(R/Ro)
  temperature /= B_COEFFICIENT; // 1/B * ln(R/Ro)
  temperature += 1.0 / (NOMINAL_TEMP + 273.15); // + (1/To)
  temperature = 1.0 / temperature; // Invert
  temperature -= 273.15; // Convert absolute temperature (Kelvin) to Celsius


  // Read gas value from MQ-2
  int gasValue = analogRead(GAS_PIN);

  // Read motion from PIR sensor
  int motion = digitalRead(PIR_PIN);

  // Display temperature
  lcd.setCursor(0, 0);
  lcd.print("Temp: ");
  lcd.print(temperature, 1); // Display with 1 decimal place
  lcd.print(" C ");

  // Display gas and alert if needed
  lcd.setCursor(0, 1);
  lcd.print("Gas:");
  lcd.print(gasValue);
  lcd.print(" ");

  // Clear previous alert/status message
  lcd.setCursor(10, 1);
  lcd.print("      "); // 6 spaces to clear "DANGER", "NORMAL", " SAFE"

  if (motion == HIGH || gasValue > 700|| temperature>47) {
    digitalWrite(BUZZER_PIN, HIGH);
    digitalWrite(LED_PIN, HIGH);
    lcd.setCursor(10, 1);
    lcd.print("DANGER");
  } else if( (gasValue > 400&&gasValue <700)||(temperature>37&&temperature<47)){ // Check gas level when motion is LOW
    digitalWrite(BUZZER_PIN, LOW); // Buzzer off
    digitalWrite(LED_PIN, LOW); // LED off
    lcd.setCursor(10, 1);
    lcd.print("NORMAL");
  } else {
    digitalWrite(BUZZER_PIN, LOW);
    digitalWrite(LED_PIN, LOW);
    lcd.setCursor(10, 1);
    lcd.print(" SAFE"); // Clear alert text
  }
  
  // 🔁 Send data to serial monitor as JSON
  Serial.print("{\"temperature\":");
  Serial.print(temperature, 1);
  Serial.print(",\"gas\":");
  Serial.print(gasValue);
  Serial.print(",\"motion\":");
  Serial.print(motion);
  Serial.println("}");

  delay(2000); // Delay for 2 seconds
}
